﻿using System;
using System.Runtime.Serialization;

namespace ReadWriteObject
{
    [Serializable]
    public class B
    {
        //₫ịnh nghĩa các thuộc tính dữ liệu
        private int intB1;
        private double dblB2;
        private A ba;
        private A pba;
        private A pba1;
        //₫ịnh nghĩa các tác vụ
        public B() { }
        public void init(int b1, double b2)
        {
            this.intB1 = b1; this.dblB2 = b2;
            ba = new A(); pba = new A(); pba1 = new A();
        }
        public void Setba(int a1, double a2, B b)
        {
            this.ba.init(a1, a2, b);
        }
        public void Setpba(int a1, double a2, B b)
        {
            this.pba.init(a1, a2, b);
        }
        public void Setpba1(int a1, double a2, B b)
        {
            this.pba1.init(a1, a2, b);
        }
    }
}
