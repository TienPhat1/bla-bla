﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace ReadWriteObject
{
    class Program
    {
        static String fbuf;
        static void Main(string[] args)
        { //₫iểm nhập của chương trình
          //xây dựng hệ thống ₫ối tượng và ghi lên file
            //Create_SaveObject();
            //₫ọc lại hệ thống ₫ối tượng
            ReadObject();
        }
        //hàm xây dựng hệ thống ₫ối tượng và ghi lên file
        public static void Create_SaveObject()
        {
            //khở tạo ₫ối tượng b theo hình ở silde 24
            B b = new B();
            b.init(2, 2.345);
            b.Setba(1, 1.234, b);
            b.Setpba(3, 3.1416, b);
            b.Setpba1(4, 4.567, b);
            //ghi ₫ối tượng b dùng kỹ thuật Serialization
            try
            {
                //1. ₫ịnh nghĩa ₫ối tượng FileStream miêu tả file chứa kết quả
                FileStream fs = new FileStream("c:\\data.obj", FileMode.Create);
                //2. tạo ₫ối tượng BinaryFormatter phục vụ ghi ₫ối tượng
                BinaryFormatter formatter = new BinaryFormatter();
                //3. gọi tác vụ Serialize của formatter ₫ể ghi ₫ối tượng
                formatter.Serialize(fs, b);
                //4. ₫óng file lại
                fs.Flush(); fs.Close();
            }
            catch (Exception e) { Console.WriteLine(e.ToString()); }
        }
        //hàm ₫ọc ₫ối tượng b dùng kỹ thuật Serialization
        public static void ReadObject()
        {
            try
            {
                //1. ₫ịnh nghĩa ₫ối tượng FileStream miêu tả file chứa dữ liệu ₫ã có
                FileStream fs = new FileStream("c:\\data.obj", FileMode.Open);
                //2. tạo ₫ối tượng BinaryFormatter phục vụ ₫ọc ₫ối tượng
                BinaryFormatter formatter = new BinaryFormatter();
                //3. gọi tác vụ Deserialize ₫ể ₫ọc ₫ối tượng từ file vào
                B b = (B)formatter.Deserialize(fs);
                //4. ₫óng file lại
                fs.Close();
            }
            catch (Exception e) { Console.WriteLine(e.ToString()); }
        } //hết hàm Main
    } //hết class program
}
