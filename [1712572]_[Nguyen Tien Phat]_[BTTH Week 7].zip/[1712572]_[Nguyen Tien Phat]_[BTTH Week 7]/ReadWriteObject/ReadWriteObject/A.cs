﻿using System;
using System.Runtime.Serialization;

namespace ReadWriteObject
{
    [Serializable]
    public class A
    {
       //₫ịnh nghĩa các thuộc tính dữ liệu
       private int intA1;
       private double dblA2;
       private B pab;
       //₫ịnh nghĩa các tác vụ
       public A() { }
       public void init(int a1, double a2, B p)
       {
           this.intA1 = a1;
           this.dblA2 = a2;
           this.pab = p;
       }
    }
}
