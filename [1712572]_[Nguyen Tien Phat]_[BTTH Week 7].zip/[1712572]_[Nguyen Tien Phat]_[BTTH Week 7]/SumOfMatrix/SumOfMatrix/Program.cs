﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SumOfMatrix
{
    class Program
    {
        static double[,] A;
        static double[,] B;
        static double[,] S;
        static int hang, cot;
        static void ReadMT(string path, ref double[,] A, ref int hang, ref int cot)
        {
            //1. Tạo đối tượng quản lí file
            FileStream stream = new FileStream(path, FileMode.Open);
            //2. Tạo đối tượng phục vụ đọc file
            StreamReader reader = new StreamReader(stream, Encoding.ASCII);
            //3. Định nghĩa các biến dữ liệu theo yêu cầu chương trình
            int i, j;
            string buf = "";
            //4. Đọc dữ liệu từ file
            ReadItem(reader, ref buf); hang = Int32.Parse(buf); //₫ọc số hàng
            ReadItem(reader, ref buf); cot = Int32.Parse(buf); //₫ọc số cột
            //phân phối vùng nhớ cho ma trận
            A = new double[hang, cot];
            //₫ọc từng phần tử ma trận
            for (i = 0; i < hang; i++)
                for (j = 0; j < cot; j++)
                {
                    ReadItem(reader, ref buf);
                    A[i, j] = Double.Parse(buf); //₫ọc số thực
                }
            //5. ₫óng các ₫ối tượng ₫ược dùng lại
            reader.Close(); stream.Close();
        }
        //hàm ghi ma trận ra file text
        static void WriteMT(string path, double[,] A, int hang, int cot)
        {
            //1. tạo ₫ối tượng quản lý file
            FileStream stream = new FileStream(path, FileMode.Create);
            //2. tạo ₫ối tượng phục vụ ghi file
            StreamWriter writer = new StreamWriter(stream, Encoding.ASCII);
            //3. ₫ịnh nghĩa các biến dữ liệu theo yêu cầu chương trình
            int i, j;
            //4. ghi dữ liệu từ các biến ra file
            writer.Write(hang); writer.Write(", "); //ghi số hàng và dấu ngăn
            writer.Write(cot); writer.WriteLine(); //ghi số cột và dấu ngăn
                                                   //ghi ma trận
            for (i = 0; i < hang; i++)
            { //ghi từng hàng ma trận
                for (j = 0; j < cot; j++)
                {
                    writer.Write(A[i, j]); writer.Write(","); //ghi phần tử i,j
                }
                writer.WriteLine(); //ghi dấu xuống hàng
            }
            //5. ₫óng các ₫ối tượng ₫ược dùng lại
            writer.Close(); stream.Close();
        }
        //hàm ₫ọc chuỗi miêu tả 1 dữ liệu nào ₫ó
        static void ReadItem(StreamReader reader, ref String buf)
        {
            char ch = '\0';
            //thiết lập chuỗi nhập ₫ược lúc ₫ầu là rỗng
            buf = "";
            while (reader.EndOfStream != true)
            {//lặp ₫ọc bỏ các dấu ngăn
                ch = (char)reader.Read(); //₫ọc 1 ký tự
                if (ch != ',' && ch != '\r' && ch != '\n')
                    break; //nếu là ký tự bình thường thì dừng
            }
            buf += ch.ToString();
            //lặp ₫ọc các ký tự của chuỗi dữ liệu
            while (reader.EndOfStream != true)
            {
                ch = (char)reader.Read(); //₫ọc 1 ký tự
                if (ch == ',' || ch == '\r' || ch == '\n')
                    return; //nếu là dấu ngăn thì dừng
                buf += ch.ToString(); //chứa ký tự vào bộ ₫ệm
            }
        }
        static void Main(string[] args)
        {
            int i, j, h = 0, c = 0;
            //₫ọc ma trận A từ file c:\A.txt
            ReadMT("C:\\a.txt", ref A, ref hang, ref cot);
            //₫ọc ma trận B từ file c:\B.txt
            ReadMT("C:\\b.txt", ref B, ref h, ref c);
            if (h != hang || c != cot)
            {
                Console.WriteLine("Hai ma trận A, B không cùng kích thước");
                return;
            }
            //phân phối ma trận tổng S
            S = new double[hang, cot];
            //tính ma trận tổng S
            for (i = 0; i < hang; i++)
                for (j = 0; j < cot; j++) S[i, j] = A[i, j] + B[i, j];
            //xuất ma trận kết quả ra file c:\S.txt
            WriteMT("C:\\S.txt", S, hang, cot);
        } //hết hàm Main
    } //hết class program
}