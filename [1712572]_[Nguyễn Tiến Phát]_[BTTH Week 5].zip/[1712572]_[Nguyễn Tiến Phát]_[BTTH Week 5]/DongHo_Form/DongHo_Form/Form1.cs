﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace DongHo_Form
{
    public partial class Form1 : Form
    {
        //₫ịnh nghĩa các biến cần dùng ₫ể quản lý Form
        Bitmap bgimg; //₫ịnh nghĩa biến chứa ảnh nền
        float xo, yo; //tọa ₫ộ tâm ₫ồng hồ
        float rh, rm, rs; //bán kính các kim giờ/phút/giây
        public Form1()
        {
            InitializeComponent();
        }

        private void myTimer_Tick(object sender, EventArgs e)
        {
            myTimer.Stop();
            this.Refresh();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            System.Reflection.Assembly myAssembly =
System.Reflection.Assembly.GetExecutingAssembly();
            //tạo ₫ối tượng Stream miêu tả ảnh bitmap
            Stream myStream =
           myAssembly.GetManifestResourceStream("DongHo_Form.Resources.haha1.png");
            //tạo ₫ối tượng ảnh bitmap nền ₫ể dùng khi cần
            bgimg = new Bitmap(myStream);
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //xác ₫ịnh ₫ối tượng mục tiêu
            Control control = (Control)sender;
            //thay ₫ổi kích thước form theo ảnh khung ₫ồng hồ
            control.ClientSize = new Size(bgimg.Width, bgimg.Height);
            //xác ₫ịnh ₫ối tượng graphics (₫ối tượng vẽ) của ₫ối tượng
            Graphics g = e.Graphics;
            //vẽ bitmap miêu tả nền ₫ồng hồ nếu chưa khai báo ảnh nền cho Form
            //g.DrawImage(bgimg, 0, 0);
            //₫ịnh nghĩa các biến cần dùng
            Pen hPen;
            float x, y;
            double goc;
            //thiết lập tâm ₫ồng hồ
            xo = (float)1.1*bgimg.Width/2-1;
            yo = xo+210;
            //thiết lập bán kính cần lắc, kim giờ/phút/giây
            rh = bgimg.Width / 2 - 145; rm = bgimg.Width / 2 - 135; rs = bgimg.Width / 2 - 125;
            //tạo Brush và vẽ tâm ₫ồng hồ
            Brush hBrush = new SolidBrush(Color.FromArgb(177, 37, 156));
            g.FillEllipse(hBrush, 1,1, 1, 1);
            //tạo pen ₫ể vẽ kim giờ
            hPen = new Pen(Color.FromArgb(0, 0, 10), 3);
            DateTime now = DateTime.Now;
            //tính góc của kim giờ
            goc = 270 + 360 * (now.Hour + (double)now.Minute / 60) / 12;
            //₫ổi góc từ ₫ộ ra radian
            goc = goc * 3.1416 / 180;
            //xác ₫ịnh tọa ₫ộ ₫ỉnh thứ 2 của kim giờ
            x = xo + (float)(rh * Math.Cos(goc));
            y = yo + (float)(rh * Math.Sin(goc));
            //vẽ kim giờ
            g.DrawLine(hPen, xo, yo, x, y);
            //tạo pen ₫ể vẽ kim phút
            hPen = new Pen(Color.FromArgb(0, 255, 0), 2);
            //tính góc của kim phút
            goc = 270 + 360 * now.Minute / 60;
            //₫ổi góc từ ₫ộ ra radian
            goc = goc * 3.1416 / 180;
            //xác ₫ịnh tọa ₫ộ ₫ỉnh thứ 2 của kim phút
            x = xo + (int)(rm * Math.Cos(goc));
            y = yo + (int)(rm * Math.Sin(goc));
            //vẽ kim phút
            g.DrawLine(hPen, xo, yo, x, y);
            //tạo pen ₫ể vẽ kim giây
            hPen = new Pen(Color.FromArgb(237, 5, 220), 1);
            //tính góc của kim giây
            goc = 270 + 360 * now.Second / 60;
            //₫ổi góc từ ₫ộ ra radian
            goc = goc * 3.1416 / 180;
            //xác ₫ịnh tọa ₫ộ ₫ỉnh thứ 2 của kim giây
            x = xo + (int)(rs * Math.Cos(goc));
            y = yo + (int)(rs * Math.Sin(goc));
            //vẽ kim giây
            g.DrawLine(hPen, xo, yo, x, y);
            //tạo chuỗi miêu tả giờ/phút/giây hiện hành
            String buf = String.Format("{0:d2}:{1:d2}:{2:d2}", now.Hour, now.Minute, now.Second);
            //tạo ₫ối tượng font chữ cần dùng
            Font myFont = new Font("Helvetica", 11);
            //tạo biến miêu tả chế ₫ộ canh giữa khi xuất chuỗi
            StringFormat format1 = new StringFormat(StringFormatFlags.NoClip);
            format1.Alignment = StringAlignment.Center;
            //xuất chuỗi miêu tả giờ/phút/giây
            g.DrawString(buf, myFont, System.Drawing.Brushes.White, xo, bgimg.Height - 29, format1);
            //cho phép timer chạy tiếp
            myTimer.Start();
        }

        
    }
}
