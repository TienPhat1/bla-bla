﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sudoku
{
    public partial class Sudoku : Form
    {
        //hàm reset ma trận Sudoku về trạng thái ban ₫ầu
        private void XoaSudoku()
        {
            int h, c;
            //lặp reset từng cell
            for (h = 0; h < LEN; h++)
                for (c = 0; c < LEN; c++)
                {
                    matran[h, c].fix = false;
                    matran[h, c].value = 0;
                }
            lblMesg.Text = "Hãy nhập số vào các ô :";
            btnGiaitiep.Enabled = false;
            btnGiai.Enabled = true;
            Invalidate();
        }
        public Sudoku()
        {
            InitializeComponent();
            int h, c;
            //phân phối vùng nhớ cho ma trận Sukodu
            for (h = 0; h < LEN; h++)
                for (c = 0; c < LEN; c++)
                    matran[h, c] = new Cell();
            //hiệu chỉnh lại kích thước Form ₫ể chứa vừa ma trận TextBox
            this.Size = new Size(9 * WCELL + xStart * 2 + 14 + 4 * wSeparator, 9 * HCELL + yStart
            + 10 + 40 + 4 * wSeparator);
            //thiết lập ô chứa cursor nhập liệu
            xcur = ycur = LEN / 2;
            //cho phép Form xử lý sự kiện phím
            this.KeyPreview = true;
            XoaSudoku();
        }
        //=================================================
        // phần code ₫ộc lập với giao diện
        //=================================================
        //₫ịnh nghĩa kiểu miêu tả thông tin về 1 ô số
        struct Cell
        {
            public bool fix; //fix = true : giá trị ô cố ₫ịnh
            public sbyte value;
        };
        //₫ịnh nghĩa các thuộc tính dữ liệu
        const int LEN = 9;
        Cell[,] matran = new Cell[LEN, LEN];
        int h, c; //tọa ₫ộ ô ₫ang xử lý
        int cachso;
        //hàm kiểm tra ô (h,c) có thể chứa giá trị val không ?
        bool Testvitri(int h, int c, sbyte val)
        {
            int h1, c1;
            int i, j;
            matran[h, c].value = 0;
            if (val > 9) return false;
            // xem có trùng với cell nào ở hàng h ?
            for (c1 = 0; c1 < LEN; c1++)
                if (matran[h, c1].value == val) return false;
            // xem có trùng với cell nào ở cot c ?
            for (h1 = 0; h1 < LEN; h1++)
                if (matran[h1, c].value == val) return false;
            // xem có trùng với cell trong vùng 3x3 ?
            h1 = h / 3 * 3;
            c1 = c / 3 * 3;
            for (i = h1; i < h1 + 3; i++)
                for (j = c1; j < c1 + 3; j++)
                    if (matran[i, j].value == val) return false;
            //chứa kết quả vào cell tương ứng
            matran[h, c].value = val;
            return true;
        }
        //hàm tìm trị phù hợp cho ô h,c ?
        //trả về TRUE nếu ₫ược, FALSE nếu không
        bool timtri(int h, int c)
        {
            sbyte val;
            sbyte d;
            if (matran[h, c].fix) return true;
            val = matran[h, c].value; val++;
            matran[h, c].value = 0;
            for (d = val; d <= 9; d++) if (Testvitri(h, c, d)) return true;
            return false;
        }
        //hàm lùi về ô ngay trước ô h,c cần xừ lý tiếp
        //trả về TRUE nếu lùi ₫ược, FALSE nếu không lùi ₫ược
        bool Back(ref int h, ref int c)
        {
            while (true)
            {
                if (c > 0) c--;
                else
                {
                    c = LEN - 1; h--;
                }
                if (h < 0) return false; //hết cách
                if (matran[h, c].fix == false) return true;
            }
        }
        //=================================================
        // phần code phục vụ giao diện với người dùng
        //=================================================
        //Định nghĩa các hằng cần dùng
        int yStart = 70; //top của bảng Sukodu
        int xStart = 10; //left của bảng Sukodu
        int wSeparator = 4; //khoảng hở giữa các vùng
        const int WCELL = 40; //₫ộ rộng từng ô
        const int HCELL = 40; //₫ộ cao tửng ô
                              //tạo pen với màu Blue, nét vẽ 2 pixel
        Pen pen = new Pen(Color.FromArgb(255, 0, 255), 1);
        //tạo brush với màu ₫ỏ, tô ₫ặc
        Brush brush = new SolidBrush(Color.FromArgb(255, 0, 255));
        Graphics g;
        int xcur, ycur; //ô nhập liệu
                        //hàm hiển thị nội dung ô row,col
        private void OutXY(int row, int col)
        {
            //tạo ₫ối tượng font chữ cần dùng
            Font myFont = new Font("Helvetica", 11);
            //tạo biến miêu tả chế ₫ộ canh giữa khi xuất chuỗi
            StringFormat format1 = new StringFormat(StringFormatFlags.NoClip);
            format1.Alignment = StringAlignment.Center;
            //tính tọa ₫ộ x,y trên form của ô row,col
            int x, y;
            x = xStart + col * WCELL + (col / 3 + 1) * wSeparator;
            y = yStart + row * HCELL + (row / 3 + 1) * wSeparator;
            //thiết lập màu nền và màu chữ cho ô
            Color bColor, fColor;
            if (matran[row, col].fix)
            {
                bColor = Color.FromArgb(0, 0, 255);
                fColor = Color.FromArgb(255, 255, 255);
            }
            else
            {
                bColor = Color.FromArgb(230, 230, 230);
                fColor = Color.FromArgb(0, 0, 0);
            }
            pen.Color = fColor;
            brush = new SolidBrush(bColor);
            //tô nền cho ô
            g.FillRectangle(brush, x + 2, y + 2, WCELL - 4, HCELL - 4);
            if (matran[row, col].value > 0) // hiển thị ô hợp lệ
                g.DrawString(matran[row, col].value.ToString(), myFont, new SolidBrush(fColor), x +
                WCELL / 2, y + 8, format1);
            if (matran[row, col].value == -1) //hiển thị ô không hợp lệ
            {
                g.DrawString("?", myFont, System.Drawing.Brushes.Red, x + WCELL / 2, y + 8,
                format1);
            }
            if (row == ycur && col == xcur)
            {
                //vẽ cursor nhập liệu ở ô hiện hành
                pen.Color = Color.DarkBlue;
                g.DrawRectangle(pen, x + 3, y + 3, WCELL - 6, HCELL - 6);
            }
        }
        private void Giai()
        {
            //bắt ₫ầu tìm trị cho ô trên trái
            cachso = 0;
            h = 0; c = 0;
            //cố gắng tìm 1 cách sắp xếp các ô số
            Tim1cach();
            btnGiai.Enabled = false;
            btnGiaitiep.Enabled = true;
        }
        //hàm cố gắng tìm 1 cách sắp xếp các ô số
        void Tim1cach()
        {
            while (h < LEN)
            { //cần tìm trị cho ô h,c
              //tìm trị cho ô h,c
                if (timtri(h, c))
                { //nếu tìm ₫ược
                  //tiếp tục ô kế tiếp
                    if (++c == LEN) { c = 0; ++h; }
                    continue;
                }
                //nếu tìm không ₫ược trị cho ô h,c
                matran[h, c].value = 0;
                if (Back(ref h, ref c)) continue;
                //hết cách --> dừng chương trình
                lblMesg.Text = "Hết cách rồi";
                return;
            }
            // tìm ₫ược cách sắp toàn bộ các ô số
            cachso++;
            lblMesg.Text = "Cách thứ " + cachso + ":";
            this.Invalidate();
            return;
        }
        //hàm tìm cách giải kế tiếp
        private void Giaitiep()
        {
            if (!Back(ref h, ref c))
                //hết cách
                lblMesg.Text = "Không còn cách nào khác nữa.";
            else
            {
                Tim1cach();
            }
        }

        private void btnGiai_Click(object sender, EventArgs e)
        {
            Giai();
        }

        private void btnGiaitiep_Click(object sender, EventArgs e)
        {
            Giaitiep();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            XoaSudoku();
        }

        private void Sudoku_Paint(object sender, PaintEventArgs e)
        {
            int x1, y1, x2, y2;
            int row, col;
            g = e.Graphics;
            //thiết lập màu vẽ
            for (row = 0; row < LEN; row++)
                for (col = 0; col < LEN; col++) OutXY(row, col);
            //thiết lập màu Magenta cho pen
            pen.Color = Color.FromArgb(255, 0, 255);
            //tạo brush với màu Magenta, tô ₫ặc
            brush = new SolidBrush(Color.FromArgb(255, 0, 255));
            //vẽ các ₫ường lưới dọc phân ô và phân vùng ma trận Sudoku
            y1 = yStart;
            y2 = yStart + LEN * HCELL + 4 * wSeparator;
            for (col = 0; col <= LEN; col++)
            {
                //xác ₫ịnh tọa ₫ộ x của ₫ường lưới
                x1 = x2 = xStart + col * WCELL + (col / 3 + 1) * wSeparator;
                if ((col - col / 3 * 3) == 0) //lưới phân vùng
                    g.FillRectangle(brush, x1 - wSeparator, y1, wSeparator, y2 - yStart);
                else
                { //lưới phân ô
                    pen.Color = Color.FromArgb(0, 0, 255);
                    g.DrawLine(pen, x1, y1, x2, y2);
                }
            }
            //vẽ các ₫ường lưới ngang phân ô và phân vùng ma trận Sudoku
            x1 = xStart;
            x2 = xStart + LEN * WCELL + 3 * wSeparator;
            for (row = 0; row <= LEN; row++)
            {
                //xác ₫ịnh tọa ₫ộ y của ₫ường lưới
                y1 = y2 = yStart + row * HCELL + (row / 3 + 1) * wSeparator;
                if ((row - row / 3 * 3) == 0) //lưới phân vùng
                    g.FillRectangle(brush, x1, y1 - wSeparator, x2 - xStart, wSeparator);
                else
                { //lưới phân ô
                    pen.Color = Color.FromArgb(0, 0, 255);
                    g.DrawLine(pen, x1, y1, x2, y2);
                }
            }
        }

        private void Sudoku_MouseDown(object sender, MouseEventArgs e)
        {
            //xác ₫ịnh tọa ₫ộ chuột
            int x = e.X, y = e.Y;
            //kiểm tra chuột có nằm trên ma trận Sudoku ?
            if (xStart > x || x > xStart + LEN * WCELL + 4 * wSeparator ||
            yStart > y || y > yStart + LEN * HCELL + 4 * wSeparator)
            {
                //nếu nằm ngoài ma trận thì không làm gì
                return;
            }
            //xác ₫ịnh ô ₫ược focus
            xcur = (x - xStart) / WCELL;
            if (xcur == LEN) xcur--;
            ycur = (y - yStart) / HCELL;
            if (ycur == LEN) ycur--;
            //vẽ lại Form
            this.Invalidate();
            return;
        }

        private void Sudoku_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keys.D0 <= e.KeyCode && e.KeyCode <= Keys.D9)
            { //các phím số 0-9
                sbyte d = (sbyte)(e.KeyCode - Keys.D0);
                if (d == 0)
                { //phím xóa ô
                    matran[ycur, xcur].fix = false;
                    matran[ycur, xcur].value = d;
                }
                else if (Testvitri(ycur, xcur, d))
                {//hợp lệ
                    matran[ycur, xcur].fix = true;
                    matran[ycur, xcur].value = d;
                }
                else
                { //không hợp lệ
                    matran[ycur, xcur].value = -1;
                    matran[ycur, xcur].fix = false;
                    lblMesg.Text = "Hãy sửa giá trị ô màu ₫ỏ vì bị lỗi.";
                }
            }
            //kiểm tra các phím ₫iều khiển
            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (ycur == 0) return;
                    ycur--; break;
                case Keys.Down:
                    if (ycur == LEN) return;
                    ycur++; break;
                case Keys.Left:
                    if (xcur == 0) return;
                    xcur--; break;
                case Keys.Right:
                    if (xcur == LEN) return;
                    xcur++; break;
                case Keys.Enter:
                    Giai(); break;
                case Keys.Delete:
                    XoaSudoku(); break;
                case Keys.Space:
                    Giaitiep(); break;
                case Keys.Escape:
                    this.Close(); break;
                default:
                    break;
            }
            Invalidate();
        }
    }

}
