﻿namespace Sudoku
{
    partial class Sudoku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGiai = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnGiaitiep = new System.Windows.Forms.Button();
            this.lblMesg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGiai
            // 
            this.btnGiai.Location = new System.Drawing.Point(13, 13);
            this.btnGiai.Name = "btnGiai";
            this.btnGiai.Size = new System.Drawing.Size(75, 23);
            this.btnGiai.TabIndex = 0;
            this.btnGiai.Text = "Giải";
            this.btnGiai.UseVisualStyleBackColor = true;
            this.btnGiai.Click += new System.EventHandler(this.btnGiai_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(175, 13);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 23);
            this.btnXoa.TabIndex = 1;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnGiaitiep
            // 
            this.btnGiaitiep.Location = new System.Drawing.Point(94, 12);
            this.btnGiaitiep.Name = "btnGiaitiep";
            this.btnGiaitiep.Size = new System.Drawing.Size(75, 23);
            this.btnGiaitiep.TabIndex = 2;
            this.btnGiaitiep.Text = "Giải tiếp";
            this.btnGiaitiep.UseVisualStyleBackColor = true;
            this.btnGiaitiep.Click += new System.EventHandler(this.btnGiaitiep_Click);
            // 
            // lblMesg
            // 
            this.lblMesg.AutoSize = true;
            this.lblMesg.Location = new System.Drawing.Point(13, 43);
            this.lblMesg.Name = "lblMesg";
            this.lblMesg.Size = new System.Drawing.Size(0, 13);
            this.lblMesg.TabIndex = 3;
            // 
            // Sudoku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 502);
            this.Controls.Add(this.lblMesg);
            this.Controls.Add(this.btnGiaitiep);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnGiai);
            this.Name = "Sudoku";
            this.Text = "Giải ô số Sudoku";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Sudoku_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Sudoku_KeyDown);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Sudoku_MouseDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGiai;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnGiaitiep;
        private System.Windows.Forms.Label lblMesg;
    }
}

