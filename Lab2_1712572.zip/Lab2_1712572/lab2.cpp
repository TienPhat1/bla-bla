#include <iostream>
#include<cmath>
#include<fstream>
#include<cstdlib>
#include<cstring>
using namespace std;

struct Position{
	double latitude;
	double longitude;
	unsigned long long pointoftime;
	Position* next=NULL;
};
void append(Position* &start, Position* new_position){
	if(start==NULL) start=new_position;
	else{
		Position*t=start;
		while(t->next!=NULL)
		t=t->next;
		t->next=new_position;
	}
}

Position* readFromFile(string filename){
	ifstream ip(filename);
	string temp;
	Position* start=NULL;

	if(!ip.is_open()) cout<<"ERROR"<<'\n';
	while(!ip.eof()){
		Position* new_position=new Position;
		getline(ip,temp,',');
		new_position->latitude=stod(temp);
		getline(ip,temp,',');
		new_position->longitude=stod(temp);
		getline(ip,temp,'\n');
		new_position->pointoftime=stoll(temp);
		append(start,new_position);
		}
		ip.close();
		return start;

}
void sortAscendingTimeList(Position* &start){
	
	for(Position* i=start;i->next!=NULL;i=i->next){
		Position* min=i;
		for(Position* j=i;j->next!=NULL;j=j->next)
			if(min->pointoftime>j->pointoftime)
				j=min;
	
		unsigned long long tempt;
		tempt=min->pointoftime;
		min->pointoftime=i->pointoftime;
		i->pointoftime=tempt;
		double templat;
		templat=min->latitude;
		min->latitude=i->latitude;
		i->latitude=templat;
		double templong;
		templong=min->longitude;
		min->longitude=i->longitude;
		i->longitude=templong;
	}

}



void printList(Position* head){
	while(head!=NULL){
				cout<<head->latitude;
				cout<<" "<<head->longitude;
				cout<<" "<<head->pointoftime;
				cout<<endl;
				head=head->next;
			}
}
//Repetiton
float lengtOfPathRep(Position* start){
	float length=0;
	for(Position* i=start;i->next!=NULL;i=i->next){
		Position* Node1=i;
		Position* Node2=i->next;
		length=length+pow(10,5)*sqrt(pow((Node1->latitude-Node2->latitude),2)+pow((Node1->longitude-Node2->longitude),2));
		}
		return length;
}
//Recursion
float lengtOfPathRec(Position* start){
	Position* Node=start->next;
	if(start->next==NULL) return 0;
	else
		return pow(10,5)*sqrt(pow(start->latitude-Node->latitude,2)+pow(start->longitude-Node->longitude,2))+lengtOfPathRec(start->next);
}

int main(){
	Position*n= readFromFile("sample.csv");
	printList(n);
	cout<<endl;
	sortAscendingTimeList(n);
	printList(n);
	cout<<lengtOfPathRep(n)<<"m"<<endl;
	cout<<lengtOfPathRec(n)<<"m"<<endl;
	return 0;
}