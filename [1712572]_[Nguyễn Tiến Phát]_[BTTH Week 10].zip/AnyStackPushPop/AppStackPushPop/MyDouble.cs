﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppStackPushPop
{
    class MyDouble
    {
        private double m_value;
        //thuộc tính giao tiếp Value
        public double Value
        {
            get { return m_value; }
            set { m_value = value; }
        }
        //hàm contructor
        public MyDouble(double val) { m_value = val; }
    }
}
