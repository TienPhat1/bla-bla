﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppStackPushPop
{
    public class RefStack<T> where T : class
    {
        private T[] data; //danh sách các phần tử trong stack
        private int top; // chỉ số phần tử ₫ỉnh stack
        private int max; // số lượng max hiện hành stack
                         // khai báo hằng miêu tả số lượng phần tử cần thêm mỗi lần thiếu stack
        private int GROWBY = 4;
        //hàm constrcutor
        public RefStack()
        {
            top = 0;
            max = GROWBY;
            data = (T[])new T[max];
        }
        //hàm push phần tử vào ₫ỉnh
        public bool push(T newVal)
        {
            T[] newdata;
            if (top == max)
            { //nếu ₫ầy stack
              //xin cấp phát lại vùng nhớ lớn hơn GROWBY phần tử sơ với stack hiện hành
                try
                {
                    newdata = (T[])new T[GROWBY + max];
                }
                catch (Exception e)
                {
                    //System.out.println("He thong het cho roi!!!");
                    return false;
                }
                //di chuyển stack hiện hành về stack mới
                for (int i = 0; i < max; i++)
                    newdata[i] = data[i];
                //cập nhật lại stack mới, ₫ể hệ thống xóa stack cũ tự ₫ộng
                data = newdata;
                max += GROWBY;
            }
            //chứa giá trị mới vào ₫ỉnh stack
            data[top++] = newVal;
            return true;
        }
        //hàm pop 1 phần tử từ ₫ỉnh stack
        public T pop()
        {
            if (top == 0) //nếu cạn stack thì tạo Exception
                throw new Exception("Cạn stack");
            else //trả về trị ở ₫ỉnh stack
                return data[--top];
        }
    } //hết class ValueStack
} //hết namespace AnyStackApp