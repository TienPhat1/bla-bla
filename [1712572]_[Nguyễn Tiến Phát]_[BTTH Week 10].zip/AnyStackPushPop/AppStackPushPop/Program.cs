﻿using AnyStackApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppStackPushPop
{
    class Program
    {
        static void Main(string[] args)
        {
            //IntStack si = new IntStack();

            //ValueStack<double> si = new ValueStack<double>();

            //Chức năng của ₫ối tượng ValueStack<double> :
            //Không thể sử dụng IntStack bởi vì parameter đưa vào hàm push ở đây là kiểu floating point, nên phải sử dụng ValueStack<double> để sử dụng được parameter kiểu floating point, Trường hợp tổng quát, ta có thể sử dụng nhiều kiểu dữ liệu khác nhau vào ValueStack mà không cần phải xác định trước đó như IntStack
            //Việc dùng Generic cho ValueStack giúp code dễ dàng được tái sử dụng với bất kì kiểu dữ liệu nào mà không cần tạo lại class
            //push và pop dữ liệu kiểu double vào Stack

            //tạo class RefStack<MyInt> và ₫ối tượng của class này ₫ể dùng
            //RefStack<MyInt> si = new RefStack<MyInt>();

            //Chức năng của ₫ối tượng RefStack<MyInt> :
            //Tương tự như ValueStack nhưng RefStack sử dụng ràng buộc là kiểu reference nên không thể dùng RefStack<int> để sử dụng kiểu int được mà phải sử dụng RefStack<MyInt>

            //tạo class RefStack<MyDouble> và ₫ối tượng của class này ₫ể dùng
            RefStack<MyDouble> si = new RefStack<MyDouble>();

            //Chức năng của ₫ối tượng RefStack < MyDouble >
            //Tương tự như ValueStack nhưng RefStack sử dụng ràng buộc là kiểu reference nên không thể dùng RefStack<double> để sử dụng kiểu double được mà phải sử dụng RefStack<MyDouble>

            //for (int i = -5; i <= 5; i++) {
            for (int i = 1; i <= 10; i++){

                //if (!si.push(i)) {

                //if (!si.push(i * 3.1416)){

                //if (!si.push(new MyInt(i))){

                if (!si.push(new MyDouble(i * 3.1416)))
                {
                    Console.WriteLine("Khong push duoc");
                    return;
                }
            }
            //pop
            try
            {
                while (true)
                {
                    //int ci = ci.pop();

                    //double ci = si.pop();

                    //Console.WriteLine("Tri vua pop ra la : " + ci);

                    //MyInt ci = si.pop();
                    //Console.WriteLine("Tri vua pop ra la : " + ci.Value);

                    MyDouble ci = si.pop();
                    Console.WriteLine("Tri vua pop ra la : " + ci);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("Can stack. Enter de ket thuc");
                Console.Read();
            }
        }
    }
}
