#include <iostream>
#include <string>
#include<cstring>
#include<fstream>
using namespace std;

struct CATEGORY
{
	string cateID;
	string cateName;
	CATEGORY* next=NULL;	
};

struct PRODUCT{
	string proID;
	string proName;
	int sellingprice;
	int importingprice;
	double quantity;
	PRODUCT* pointoproduct=NULL;
	CATEGORY* pointocategory=NULL;

};


void appendCategory(CATEGORY* &start, CATEGORY* c){
	if(start==NULL){
		start=c;
	}
	else{
		CATEGORY* pTempCate=start;
		while(pTempCate->next!=NULL)
			pTempCate=pTempCate->next;
		pTempCate->next=c;
	}
}

void appendProduct(PRODUCT* &start, PRODUCT* p){
	if(start==NULL){
		start=p;
	}
	else{
		PRODUCT* pTempPro=start;
		while(pTempPro->pointoproduct!=NULL) pTempPro=pTempPro->pointoproduct;
		pTempPro->pointoproduct=p;
	}
}
void printp(PRODUCT* p){
	for(PRODUCT* temp=p;temp!=NULL;temp=temp->pointoproduct){
		cout<<temp->proID<<" ";
		cout<<temp->proName<<" ";
		cout<<temp->sellingprice<<" ";
		cout<<temp->importingprice<<" ";
		cout<<temp->quantity<<" ";
		cout<<temp->pointocategory->cateID<<endl;
	}
}

PRODUCT* readFromFile(string category, string product){
	ifstream Category(category);
	ifstream Product(product);
	string temp;
	CATEGORY* startcategory=NULL;
	PRODUCT* startproduct=NULL;
	while(!Category.eof()){
		CATEGORY* new_category=new CATEGORY;
	getline(Category,temp,',');new_category->cateID=temp;
	getline(Category,temp,'\n');new_category->cateName=temp;
	appendCategory(startcategory,new_category);
	}
	while(!Product.eof()){
			PRODUCT* new_product=new PRODUCT;
			getline(Product,temp,',');new_product->proID=temp;
			//cout<<temp;
			getline(Product,temp,',');new_product->proName=temp;
			getline(Product,temp,',');new_product->sellingprice=stoi(temp);
			getline(Product,temp,',');new_product->importingprice=stoi(temp);
			getline(Product,temp,',');new_product->quantity=stod(temp);
			getline(Product,temp);
			//cout<<temp;
			CATEGORY* pTem=startcategory;
			while(pTem!=NULL){
				if(temp==pTem->cateID){
					new_product->pointocategory=pTem;
				}
				pTem=pTem->next;
			}
			appendProduct(startproduct,new_product);
		}
	return startproduct;
}


void print(PRODUCT* g){
	int count=0;
	for(PRODUCT*p=g;p!=NULL;p=p->pointoproduct){
		PRODUCT* temp=p;
		if(p->pointoproduct!=NULL){ 
			temp=temp->pointoproduct;
		}
		if(temp->pointocategory->cateID!=p->pointocategory->cateID){
			count++;
	}
		if(p->pointoproduct==NULL&&temp->pointocategory->cateID!=p->pointocategory->cateID){
			count++;
		}

	}
	cout<<count<<" categories"<<endl;
	for(PRODUCT*p=g;p!=NULL;p=p->pointoproduct){
		PRODUCT* temp=p;
		if(p->pointoproduct!=NULL){ 
			temp=temp->pointoproduct;
		}
		if(temp->pointocategory->cateID!=p->pointocategory->cateID){
			cout<<"----------------"<<endl;
			cout<<"ID: "<<p->pointocategory->cateID<<endl;
			cout<<"Name: "<<p->pointocategory->cateName<<endl;
	}
		if(p->pointoproduct==NULL&&temp->pointocategory->cateID!=p->pointocategory->cateID){
			cout<<"ID: "<<p->pointocategory->cateID<<endl;
			cout<<"Name: "<<p->pointocategory->cateName;
		}

	}
}

bool deleteProduct(PRODUCT* &start, double quantity){
	bool check=false;
	PRODUCT* ptemp=start;
	while(ptemp!=NULL){
		if(ptemp->quantity<quantity){
			if(ptemp==start) start=start->pointoproduct;
			else{
			PRODUCT* current=start;
		while(current->pointoproduct!=ptemp) current=current->pointoproduct;
		current->pointoproduct=ptemp->pointoproduct;
		ptemp->pointoproduct=NULL;
		ptemp=current;
	}
		check=true;
		}
		ptemp=ptemp->pointoproduct;
	}
	return check;
}

double sellingFromFile(PRODUCT* &pHead,string filename){
	ifstream Ip(filename);
	string id,quantity;
	double totalamount=0.0, temp;
	while(!Ip.eof()){
		getline(Ip,id,',');
		getline(Ip,quantity, '\n');
		temp=stod(quantity);
		PRODUCT* ptemp=pHead; 
		while(ptemp!=NULL){
			if(ptemp->proID == id){
				totalamount=totalamount+(double)ptemp->sellingprice*temp;
				if(ptemp->quantity>temp) ptemp->quantity=ptemp->quantity-temp;
				else ptemp->quantity=0;
			
			}
		ptemp=ptemp->pointoproduct;
		}
	}
	return totalamount;
}
int main(){
	PRODUCT *p=readFromFile("category.csv","product.csv");
	print(p);
	cout<<"Total amont: "<<sellingFromFile(p,"sellingdata.csv")<<endl;
	printp(p);
	cout<<deleteProduct(p,300)<<endl;
	printp(p);
	return 0;
}