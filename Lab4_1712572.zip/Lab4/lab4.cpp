#include <iostream>
using namespace std;
#define MAX 5 
//1. Stack.....
struct NodeS{
	int data;
	NodeS* next=NULL;
};
struct Stack{
	NodeS* top=NULL;
	int count = 0;
};
Stack* creatStack(Stack* &S){
	S->count=0;
	S->top=NULL;
	return S;
}
void pushStack(Stack* &S,int data){
	NodeS* new_NodeS=new NodeS;
	new_NodeS->data=data;
	if(S->top==NULL){ S->top=new_NodeS;
		S->top->next=NULL;
	}
	else{
	new_NodeS->next=S->top;
	S->top=new_NodeS;
	}
	S->count++;
}

int popStack(Stack *&S){
	int data;
	if(S->count>0){
		NodeS* ptemp=S->top;
		S->top=ptemp->next;
		data=ptemp->data;
		ptemp->next=NULL;
		delete ptemp;
		S->count--;
	}
		return data;
	
}
void topStack(Stack *S){
	cout<<S->top->data;
	return;
}

bool isEmptyStack(Stack *S){
	if(S->top==NULL)
		return true;
	else return false;
}

bool isFullStack(Stack* S,int numberStack){
	if(S->count==numberStack) return true;
	else return false;
}

void clearStack(Stack* &S,int count){
	if(count==0) return;
	else{
		popStack(S);
		return clearStack(S,count-1);
	}
}

int SizeStack(Stack* S){
	return S->count; 
}
void printStack(Stack* S){
	NodeS *temp = S->top;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
		
	}
}
//2.Queue......
struct NodeQ{
	int data;
	NodeQ* next=NULL;
};
struct Queue{
	int count=0;
	NodeQ* front=NULL;
	NodeQ* rear=NULL;
};

Queue* creatQueue(Queue* &Q){
	Q->front=NULL;
	Q->rear=NULL;
	return Q;
}

void EnQueue(Queue* &Q,int data){
	NodeQ* new_Node=new NodeQ;
	new_Node->data=data;
	if(Q->front==NULL){ 
		Q->front=new_Node;
		Q->rear=new_Node;
	}
	else{ 
		Q->rear->next=new_Node;
		Q->rear=new_Node;
		}
	Q->count++;
}
int  DeQueue(Queue* &Q){
	int data;
	if(Q->front==Q->rear){
		Q->count--;
		data=Q->front->data;
		Q->front=NULL;
		Q->rear=NULL;
	}
	else{
	NodeQ* ptemp=Q->front;
	Q->front=Q->front->next;
	data=ptemp->data;
	ptemp->next=NULL;
	Q->count--;
	delete ptemp;
	}
	return data;
}
int queueFront(Queue*S){
	if(S->front=NULL)
	cout<<" Queue Empty";
	return S->front->data;
}
int queueRear(Queue*S){
	if(S->rear=NULL)
		cout<<" Queue Empty";
	return S->rear->data;
}
bool isEmptyQueue(Queue*Q){
	if(Q->front==NULL&&Q->rear==NULL)
		return true;
	return false;
}
bool isFullQueue(Queue* Q){
	if(Q->count==MAX) return true;
	return false;
}
 void clearQueue(Queue* Q,int &x){
 	if(isEmptyQueue(Q)) return;
 	while(Q->count>0){
 		DeQueue(Q);
 	}
 }
 int SizeQueue(Queue* Q){
 	return Q->count;
 }
void printQueue(Queue* Q){
	NodeQ* ptemp=Q->front;
	while(ptemp!=NULL){
		cout<<ptemp->data<<" ";
		ptemp=ptemp->next;
	}
}

//3.stackToQueue

Queue* stackToQueue(Stack* &S){
	int x;
	Queue* new_Queue=new Queue;
	new_Queue=creatQueue(new_Queue);
	while(S->count>0){
		x=popStack(S);
		EnQueue(new_Queue,x);
	}
	return new_Queue;
}

Stack* queueToStack(Queue* &Q){
	int data;
	Stack* new_Stack=new Stack;
	new_Stack=creatStack(new_Stack);
	Stack* temp_Stack=new Stack;
	temp_Stack=creatStack(temp_Stack);
	while(Q->count>0){
		data=DeQueue(Q);
		pushStack(temp_Stack,data);
	}
	while(temp_Stack->count>0){
		data=popStack(temp_Stack);
		pushStack(new_Stack,data);
	}
	return new_Stack;
}
int main(){
	Stack* stack=new Stack;
	Queue* queue= new Queue;

	stack=creatStack(stack);
	if(isEmptyStack(stack)) cout<<" Stack Empty";
	for(int i=0;i<MAX;i++)
		pushStack(stack,i);
	if(isFullStack(stack)) cout<<" Stack Fully";
	printStack(stack);
	cout<<"size stack before pop: "<<SizeStack(stack)<<endl;
	cout<<"data pop"<<popStack(stack)<<endl;
	cout<< "size stack after pop: "<<SizeStack(stack)<<endl;
	clearStack(stack);
	printStack(stack);

	queue=creatQueue(queue);
	if(isEmptyQueue(queue)) cout<<" Queue Empty";
	for(int i=0;i<MAX;i++)
		EnQueue(queue,i);
	printQueue(queue);
	if(isFullQueue(queue)) cout<<" Queue Fully";
	cout<<"size queue before dequeue: "<<SizeQueue(queue)<<endl;
	cout<<"data dequeue:" <<DeQueue(queue)<<endl;
	cout<<"size queue after dequeue: "<<SizeQueue(queue)<<endl;
	clearQueue(queue);
	printQueue(queue);
	return 0;
}