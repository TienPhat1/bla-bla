#include <iostream>
#include <string>
#include <sstream> 
using namespace std;

class TreeNode{
private:
	string character;
	int count;
	TreeNode* left=NULL;
	TreeNode* right=NULL;
public:
	TreeNode(string character){
		this->character=character;
		count=1;
	};
	TreeNode(char character) {
		this->character=character;
		count = 1;
	}
	~TreeNode(){
		this->character="";
		this->count=0;
		this->left=NULL;
		this->right=NULL;
	};
	void increaseCount(){
		count++;
		setCount(count);
	};

	//get/set methods
	int getCount(){
		return count;
	};
	void setCount(int newCount){
		if(newCount>0)
		count=newCount;
	};
	string getChar(){
		return character;
	};
	void setChar(int newChar){
		character=newChar;
	};

	TreeNode* getLeft(){
		return left;
	};
	void setLeft(TreeNode* newLeft){
			left=newLeft;
	};
	TreeNode* getRight(){
		return right;
	};
	void setRight(TreeNode* newRight){
			right=newRight;
	};
	friend void insertNode(TreeNode* &root,TreeNode* node){
		if(root == NULL){ 
			root=node;
			}
		else{
		 if(root->character.compare(node->character)>0){
			insertNode(root->left,node);
		}
		 else if(root->character.compare(node->character)<0)
			insertNode(root->right,node);
		else root->increaseCount();
		}

	}

	friend int seachNode(TreeNode* root,string character){
		if(root==NULL){ return 0;}
		else{
			
			if(character.compare(root->character)<0){
				return seachNode(root->left,character);
			}
			else if(character.compare(root->character)>0){
				return seachNode(root->right,character);
			}
			else
			return root->getCount();
		}
	}
	friend void removeNode(TreeNode* &root, string character){
			if(root==NULL){ cout<<" Not found"; return;}
				
			else if(root->character.compare(character)>0)
					return removeNode(root->left,character);
			else if(root->character.compare(character)<0)
					return removeNode(root->right,character);
			else{ 
				TreeNode* pDel=root;
		if(root->left==NULL)
			root=root->right;
		else if(root->right==NULL)
			root=root->left;
		else{
			TreeNode* parent=root;
			pDel=parent->left;
			while(pDel->right!=NULL){
				parent=pDel;
				pDel=pDel->right;
				}
			root->character=pDel->character;
			if(parent=root)
				parent->left=pDel->left;
			else
				parent->right=pDel->left;
			}
		delete pDel;
			}

	}

	friend void printNode(TreeNode* root){
		if(root!=NULL){
			printNode(root->getLeft());
			cout<<root->getChar()<<" ";
			printNode(root->getRight());
		}
	}
};

class BinarySeachTree{
public:
	TreeNode* root=NULL;
	void insert(TreeNode* node){ insertNode(root,node);}
	int seach(string character){ return seachNode(root,character);}
	void remove(string character){ removeNode(root,character);}
	void print(){printNode(root);}
};

BinarySeachTree* buildTreeFromString(string str){
	BinarySeachTree* root=new BinarySeachTree();
	for(int i=0;i<str.length();i++){
		TreeNode* node=new TreeNode(str[i]);
		root->insert(node);
	}
	return root;
}


int main(){
	string str="bstttresbr";
	BinarySeachTree* bst=buildTreeFromString(str);
	bst->print();
	cout<<endl;
	cout<<"b= "<<bst->seach("b")<<endl;//6 times
	cout<<"t= "<<bst->seach("t")<<endl;//13 times
	cout<<"s= "<<bst->seach("s")<<endl;//24 times
	return 0;
}