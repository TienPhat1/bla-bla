﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace Viết_phần_mềm_demo
{
    public partial class Form1 : Form
    {
        class Params //₫ịnh nghĩa class ₫ối tượng chứa các tham số cần truyền cho thread con
        {
            public Thread t; //₫ối tượng quản lý thread tương ứng
            public int sr; //hàng bắt ₫ầu tính
            public int er; //hàng kết thúc tính +1
            public int id; //chỉ số thread trong danh sách quản lý
            public Params(Thread t, int s, int e, int i)
            {
                this.t = t; sr = s;
                er = e;
                id = i;
            }
        };
        //₫ịnh nghĩa 3 biến ma trận
        double[,] A;
        double[,] B;
        double[,] C;
        //₫ịnh nghĩa biến chứa số hàng/cột của ma trận
        int N;
        //₫ịnh nghĩa danh sách trạng thái thi hành của các thread con
        int[] stateLst = new int[20];
        //₫ịnh nghĩa danh sách thời gian thi hành của các thread con
        System.TimeSpan[] dateLst = new System.TimeSpan[20];
        //₫ịnh nghĩa biến miêu tả quyền ưu tiên của chương trình
        ProcessPriorityClass myPrio = ProcessPriorityClass.Normal;
        Process MyProc;
        //₫ịnh nghĩa danh sách các quyền ưu tiên cho các thread
        ThreadPriority[] tPrio = {
 ThreadPriority.Lowest, ThreadPriority.BelowNormal, ThreadPriority.Normal,
 ThreadPriority.AboveNormal, ThreadPriority.Highest};
        //₫ịnh nghĩa hàm các hàng ma trận tích theo yêu cầu trong tham số
        void TinhTich(object obj)
        {
            DateTime t1 = DateTime.Now;
            Params p = (Params)obj;
            int h, c, k;
            for (h = p.sr; h < p.er; h++)
                for (c = 0; c < N; c++)
                {
                    double s = 0;
                    for (k = 0; k < N; k++)
                        s = s + A[h, k] * B[k, c];
                    C[h, c] = s;
                }
            //ghi nhận ₫ã hoàn thành nhiệm vụ
            stateLst[p.id] = 1;
            //ghi nhận thời gian tính
            dateLst[p.id] = DateTime.Now.Subtract(t1);
        }
        public Form1()
    {
        InitializeComponent();
    }

        private void btnCham_Click(object sender, EventArgs e)
        {
            //thiết lập chế ₫ộ quyền ưu tiên realtime cho chương trình
            myPrio = ProcessPriorityClass.BelowNormal;
        }

        private void btnNhanh_Click(object sender, EventArgs e)
        {
            //thiết lập chế ₫ộ quyền ưu tiên realtime cho chương trình
            myPrio = ProcessPriorityClass.RealTime;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            //xác ₫ịnh ₫ối tượng quản lý process hiện hành
            MyProc = Process.GetCurrentProcess();
            //thay ₫ổi quyền ưu tiên theo yêu cầu người dùng
            MyProc.PriorityClass = myPrio;
            //xác ₫ịnh số thread tham gia tính tích 2 ma trận
            int cnt = Int32.Parse(txtThreads.Text);
            int i;
            //ghi nhận thời ₫iểm bắt ₫ầu tính tích
            DateTime t1 = DateTime.Now;
            if (cnt == 1)
            { //dùng thuật giải tuần tự
                TinhTich(new Params(null, 0, N, 0));
            }
            else //dùng thuật giải song song gồm cnt-1 thread con và 1 thread chính có sẵn
            {
                Thread t;
                for (i = 0; i < cnt - 1; i++)
                {//lặp tạo và chạy từng thread con
                    stateLst[i] = 0; //ghi nhận thread i chưa chạy xong
                                     //tạo thread mới ₫ể chạy hàm TinhTich
                    t = new Thread(new ParameterizedThreadStart(TinhTich));
                    //thiết lập quyền ưu tiên cho thread i
                    t.Priority = tPrio[i % 5];
                    //hiển thị ₫ộ ưu tiên của thread i
                    lbKetqua.Items.Add(String.Format("Thread {0:d} co do uu tien = {1:d}", i,
                   t.Priority.ToString()));
                    //kích hoạt thread i chạy và truyền các tham số cần thiết cho nó
                    t.Start(new Params(t, i * N / cnt, (i + 1) * N / cnt, i));
                }
                //bản thân thread cha cũng tính N/cnt hàng cuối của ma trận tích
                TinhTich(new Params(null, (cnt - 1) * N / cnt, N, cnt - 1));
                //chờ ₫ợi các thread con hoàn thành
                for (i = 0; i < cnt - 1; i++)
                    while (stateLst[i] == 0) ; //cho
            }
            //ghi nhận thời ₫iểm kết thúc tính tích
            DateTime t2 = DateTime.Now;
            System.TimeSpan diff;
            //hiển thị ₫ộ ưu tiên hiện hành của chương trình
            lbKetqua.Items.Add("Ung dung da chay voi quyen " + myPrio.ToString());
            //hiển thị thời gian tính của từng thread con
            for (i = 0; i < cnt - 1; i++)
            {
                diff = dateLst[i];
                lbKetqua.Items.Add(String.Format("Thread {0:d} chay ton {1:d2} phut {2:d2} giay { 3:d3} ms", i, diff.Minutes, diff.Seconds, diff.Milliseconds));
            }
            diff = t2.Subtract(t1);
            //hiển thị thời gian tổng cộng ₫ể tính tích
            lbKetqua.Items.Add(String.Format("{0:d} threads ==> Thoi gian chay la {1:d2} phut { 2:d2} giay { 3:d3} ms", cnt, diff.Minutes, diff.Seconds, diff.Milliseconds));
        }
    }
}
