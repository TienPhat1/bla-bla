#include<iostream>
using namespace std;

//Merge Sort....

//Creating merge function:
//Operation:
//It divided input data array to two halves
//call itselt for two halves and then merge 2 sorted halves

void merge(int arr[],int l,int m,int r){
	int n1=m-l+1;
	int n2=r-m;
	//Creat two temp array 
	int L[n1],R[n2];
	//Coppy data to temp array to L[] and R[]
	for(int i=0;i<n1;i++)
		L[i]=arr[l+i];
	for(int j=0;j<n2;j++)
		R[j]=arr[m+j+1];
	//Merge the temp arrays back in arr[1...r]
	//Initial i(first subarray),j(second subarray),	k(merge)
	int i=0;
	int j=0;
	int k=l;
	while(i<n1&&j<n2){
		if(L[i]<=R[j]){
			arr[k]=L[i];
			i++;
		}
		else{
			arr[k]=R[j];
			j++;
		}
		k++;
	}
	//Coppy remaining elements of L[],if there are any
	while(i<n1){
		arr[k]=L[i];
		i++;
		k++;
	}
	//Coppy remaining elements of R[],if there are any
	while(j<n2){
		arr[k]=R[j];
		j++;
		k++;
	}	
}
//Creat merge sort function....
//Find middle point to divided array into 2 halves
//Merge Sort for fisrt halves
//Merge Sort for second halves
//Merge the two halves sorted in step 2 and step 3
void mergeSort(int arr[],int l,int r){
	if(l<r){
	int m=l+(r-l)/2;
	mergeSort(arr,l,m);
	mergeSort(arr,m+1,r);
	merge(arr,l,m,r);
	}
}
void printArr(int arr[],int size){
	for(int i=0;i<size;++i)
		cout<<arr[i]<<" ";
	return;
}
int main(){
	int size=12;
	int arr[]={2,4,5,6,7,3,8,9,0,10,22,11};
	printArr(arr,size);
	mergeSort(arr,0,size-1);
	cout<<endl;
	printArr(arr,size);
	return 0;
}