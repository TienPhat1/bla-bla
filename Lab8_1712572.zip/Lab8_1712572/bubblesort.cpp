#include<iostream>
using namespace std;

void swap(int &a,int &b){
	int t;
	t=a;
	a=b;
	b=t;
}

void bubbleSort(int* arr,int size){
	for(int i=0;i<size;i++)
		for(int j=size-1;j>i;j--){
			if(arr[j]<arr[j-1])
				swap(arr[j],arr[j-1]);
		}
}

int main(){
	int size=10;
	int *arr=new int[size];
	for(int i=0;i<size;i++)
		cin>>arr[i];
	for (int i = 0; i < size; ++i)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	bubbleSort(arr,size);
	for (int i = 0; i <size; ++i)
	{
		cout<<arr[i]<<" ";
	}
	return 0;
}