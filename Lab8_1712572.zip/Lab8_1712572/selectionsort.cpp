#include <iostream>
using namespace std;

void swap(int &a,int &b){
	int t;
	t=a;
	a=b;
	b=t;
}
void selectSort(int *arr,int size,int i){
	if(i==size-1) return;
	int min=arr[i];
	for(int j=i;j<size;j++){
		if(arr[j]<min){
			min=arr[j];
			swap(arr[i],arr[j]);
		}
	}
	selectSort(arr,size,++i);
}
int main(){
	int size=10;
	int *arr=new int[size];
	for(int i=0;i<size;i++)
		cin>>arr[i];
	for (int i = 0; i < size; ++i)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	selectSort(arr,size,0);
	for (int i = 0; i <size; ++i)
	{
		cout<<arr[i]<<" ";
	}
	return 0;
}