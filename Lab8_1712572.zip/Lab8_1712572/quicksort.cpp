#include<iostream>
using namespace std;

//Quick Sort function
//Step 1.Creat partition function

int partition(int *arr,int low,int hight){
	int t;
	int temp=arr[low];
	int i=low+1;
	int j=hight;
	while(i<=j){
		while(i<=j&&arr[i]<=temp)
			i++;
		while(i<=j&&arr[j]>temp)
			j--;
		if(i<=j){
			t=arr[i];
			arr[i]=arr[j];
			arr[j]=t;
			i++;
			j++;
			}
		}
		t=arr[low];
		arr[low]=arr[j];
		arr[j]=t;
	return j;
}

//Step 2. Creat QuickSort function
void quickSort(int *arr,int low,int hight){
	int pivot;
	if(low<hight){
		pivot=partition(arr,low,hight);
		quickSort(arr,low,pivot-1);
		quickSort(arr,pivot+1,hight);
	}
}
void printArr(int *arr,int size){
	for(int i=0;i<size;++i)
		cout<<arr[i]<<" ";
	return;
}
int main(){
	int size=10;
	int* arr=new int[size];
	for(int i=0;i<size;i++)
		cin>>arr[i];
	printArr(arr,size);
	quickSort(arr,0,size-1);
	printArr(arr,size);

	return 0;
}