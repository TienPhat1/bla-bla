#include<iostream>
using namespace std;

//Heap Sort function
//Creat build heap function
// Heap have form
/*				/....\
			  2*i
			/	\
	     2*i+1 2*i+2
*/
void swap(int &a,int &b){
	int t;
	t=a;
	a=b;
	b=t;
	return;
}
void buildHeap(int* arr,int size){
	for(int i=0;i<size;i++)
		cin>>arr[i];
	return;
}

//Creat reUpHeap function

void reUpHeap(int* arr,int size,int i){
	if(i<0) return;
	else{
		if(2*i+2<size&&arr[2*i+2]>arr[i])
			swap(arr[2*i+2],arr[i]);
		if(2*i+1<size&&arr[2*i+1]>arr[i])
			swap(arr[2*i+1],arr[i]);
		reUpHeap(arr,size,i-1);
	}
}
void heapSort(int*arr,int size){
	for(int i=size/2-1;i>=0;i--)
		reUpHeap(arr,size,i);
	for(int i=size-1;i>=0;i--){
		reUpHeap(arr,i+1,(i+1)/2);
		swap(arr[i],arr[0]);
	}
}
void print(int* arr,int size){
	for(int i=0;i<size;++i){
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	return;
}
int main(){
	int size=10;
	int *arr=new int[size];
	buildHeap(arr,size);
	print(arr,size);
	heapSort(arr,size);
	print(arr,size);
	return 0;
}