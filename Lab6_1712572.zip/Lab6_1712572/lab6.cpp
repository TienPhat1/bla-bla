#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;

class TreeNode{
private:
	int key;
	int height;
	TreeNode* left=NULL;
	TreeNode* right=NULL;
public:
	TreeNode(int key){
		this->key=key;
		height=1;
	};
	~TreeNode(){
		this->key=0;
		this->height=0;
		this->left=NULL;
		this->right=NULL;
	};
	int max(int a,int b){
		return (a>b)?a:b;
	}
	int heightTree(TreeNode* root){
		if(root==NULL) return 0;
		return root->height;
	}
	TreeNode* srl(TreeNode* &p1){                    //LL
		TreeNode* p2;
		p2 = p1->left;
		p1->left = p2->right;
		p2->right = p1;
		p1->height = max(heightTree(p1->left),heightTree(p1->right)) + 1;
		p2->height = max(heightTree(p2->left),p1->height) + 1;
	return p2;
	}
	TreeNode* srr(TreeNode* &p1){                   //RR
		TreeNode* p2;
		p2 = p1->right;
		p1->right = p2->left;
		p2->left = p1;
		p1->height = max(heightTree(p1->left),heightTree(p1->right)) + 1;
		p2->height = max(p1->height,heightTree(p2->right)) + 1;
	return p2;
	}
	TreeNode* drl(TreeNode* &p1){                   //RL
		p1->left=srr(p1->left);
	return srl(p1);                           
	}
	TreeNode* drr(TreeNode* &p1){                   //LR
		p1->right = srl(p1->right);
	return srr(p1);
	}
	int getbalance(TreeNode* root){
		return heightTree(root->left)-heightTree(root->right);
	}
	void insertTree(TreeNode* &root,TreeNode* node)
	{
		if(root==NULL)
			root=node;
		else{
			if(node->key>root->key){
				insertTree(root->right,node);
				if(getbalance(root)==2)
				{
					if(node->key<root->left->key)
						root=srl(root);
					else
						root=drl(root);
					}
				}
			else if(node->key<root->key){
				insertTree(root->left,node);
				if(getbalance(root)==-2)
				{
					if(node->key>root->right->key)
						root=srr(root);
					else
						root=drr(root);
					}
				}
			else
				cout<<" Key exists....."<<endl;
			}
	}

	void removeTree(TreeNode* root,int key){
		TreeNode* ptem;
		if(root==NULL)
			cout<<"Sorry! Tree is empty..."<<endl;
		else
		{
			if(key<root->key)
				removeTree(root->left,key);
			else if(key>root->key)
				removeTree(root->right,key);
			else if(root->left==NULL&&root->right==NULL){
				ptem=root;
				delete ptem;
			}
			else if(root->left==NULL){
				ptem=root;
				root=root->right;
				delete ptem;
			}
			else if(root->right==NULL){
				ptem=root;
				root=root->left;
				delete ptem;
			}
			else{
				if(getbalance(root)==2)
				{
					if(getbalance(root->left)==1)
						root=srl(root);
					else
						root=drl(root);
				}
				if(getbalance(root)==-2)
				{
					if(getbalance(root->right)==-1)
						root=srr(root);
					else
						root=drr(root);
				}
			}

		}
	}

	TreeNode* getDataFromFile(TreeNode* &root, string namefile){
		int val;
		ifstream ifs(namefile);
		if(ifs.fail()) cout<<" File empty...."<<endl;
		while(!ifs.eof()){
			ifs>>val;
			insertTree(root,new TreeNode(val));
		}
		ifs.close()
	}

	void writeDatatoFile(TreeNode* root,int arr[100],string namefile){
		int val; 
		ofstream ofs(namefile);

	}
	void getDataFormTree(TreeNode* root,int &arr[100],int i=0){
		if(root!=NULL){
			getDataFormTree(root->left,a,i++);
			arr[i++]=root->key;
			getDataFormTree(root->right,a,i++);
		}
	}
	void printTree(TreeNode* root)
	{	if(root!=NULL){
		
		printTree(root->left);
		cout<<root->key<<" ";
		printTree(root->right);
		}
	}

};

int main()
{
	TreeNode* root=NULL;
	root->insertTree(root,new TreeNode(9));
	root->insertTree(root,new TreeNode(7));
	root->insertTree(root,new TreeNode(1));
	root->insertTree(root,new TreeNode(4));
	root->insertTree(root,new TreeNode(6));
	root->insertTree(root,new TreeNode(2));
	root->insertTree(root,new TreeNode(3));
	root->insertTree(root,new TreeNode(10));
	root->insertTree(root,new TreeNode(22));
	root->printTree(root);

}