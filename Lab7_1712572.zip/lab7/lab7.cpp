#include <iostream>
#include <cmath>
using namespace std;


//Q1 Print.....
	
void printHeap(int* maxHeap,int size){
	int h=(int)log2(size)+1;
	int lenght=3*(pow(2,h));
	int k=1,step=4,val,m=0,n=1;
	for(int l=0;l<h-1;l++){
	val=(int)(lenght-3*(4*n))/(4*k);
	for(int i=1;i<step;++i){
		if((i+1)%3==0){
			for(int j=1;j<2*val+2;j++){
				if(j<=val||j>val+1)
					cout<<"_";
				else{
					if(maxHeap[m]/10==0)
						cout<<"00"<<maxHeap[m];
					else if(maxHeap[m]/100==0)
						cout<<"0"<<maxHeap[m];
					else 
						cout<<maxHeap[m];
				}
			}
			m++;	
			cout<<"   ";
		}
		if((i+1)%3!=0){
			for(int j=1;j<val+4;j++)
				cout<<" ";	
			}
		}
		k=2*k;
		step=step+3*n;
		n=n*2;
		cout<<"\n";
	}
	int o=m;
	for(int i=0;i<2*(size-o);i++){
		if(i%2==0){
			if(maxHeap[m]/10==0)
				cout<<"00"<<maxHeap[m];
			else if(maxHeap[m]/100==0)
						cout<<"0"<<maxHeap[m];
			else 
				cout<<maxHeap[m];
			m++;
		}
		else
			cout<<"   ";
	}
}

void swap(int &a,int &b){
	int t;
	t=a;
	a=b;
	b=t;
	return;
}

void reHeapUp(int* &maxHeap,int position){
	if(position>0){
		int parent=(position-1)/2;
		if(maxHeap[position]>maxHeap[parent]){
			swap(maxHeap[position],maxHeap[parent]);
			reHeapUp(maxHeap,parent);
		}
	}
	return;

}
void buildHeap(int* &maxHeap, int size)
{
	for(int i=1;i<size;++i)
		reHeapUp(maxHeap,i);
		
}

//Q2 Binary search tree to heap: Write a function to convert a binary search tree to a max heap

class Node{
public:
	int data;
	Node* left=NULL;
	Node* right=NULL;

	Node(int newdata){
		this->data=newdata;
	}
};

void insert(Node* &root,Node* newNode){
	if(root==NULL){
		root=newNode;
	}
	else{
		if(root->data>newNode->data)
			insert(root->left,newNode);
		if(root->data<newNode->data)
			insert(root->right,newNode);
	}
}

void addData(Node*& root,int size){
	int data;
	for(int i=0 ; i < size ; i++){
		cout<<"Insertsion #"<<i<<":";
		cin>>data;
		insert(root,new Node(data));
		cout<<endl;
	}
}
 void BSTtoHeap(Node* root,int* &heap,int size){
 	static int i=0;
 	if(root!=NULL){
 		
 		BSTtoHeap(root->left,heap,size);
 		BSTtoHeap(root->right,heap,size);
 		heap[i]=root->data;
 		i++;
 	}
 }
 //Q3Implement the following hash functions:
int f1(int *arr,int end){
	int result;
	for(int i=0;i<=end;++i)
		result+=7*arr[i];
	result=result%7719;
	return result;
}

int f2(int* arr,int end){
	int result;
	for(int i=0;i<=end;++i)
		result+=7*(pow(arr[i],arr[i]));
	result=result%7719;
	return result;
}

//Q4 a.Find errors in the following functions and fix them:
/*void reheapUp(int* maxHeap,int position){
	if(position>0){
	int parent=(position-1)/2;
	if(maxHeap[position]>maxHeap[parent])
		swap(maxHeap[posittion],maxHeap[parent]);
		reHeapUp(maxHeap,parent);
	}
}

void reheapDown(int* maxHeap,int position,int size){
	int leftChild=position*2+1;
	int rightChild=position*2+2;
	int largeChild;
	if(leftChild<=size-1){
		if((rightChild<=size-1)&&maxHeap[rightChild]<maxHeap[leftChild])
			largeChild=rightChild;
		else
			largeChild=leftChild;
		if(maxHeap[largeChild]>maxHeap[position]){
			swap(largeChild,position);
			reheapDown(largeChild,size-1)
		}
	
	}
}
*/
//b.Write a function to convert a max heap tree to a min heap tree.
void reHeapDown(int*& maxHeap,int position,int size){
	int leftChild=position*2+1;
	int rightChild=position*2+2;
	int largeChild;
	if(leftChild<=size-1){
		if((rightChild<=size-1)&&maxHeap[rightChild]<maxHeap[leftChild])
			largeChild=rightChild;
		else
			largeChild=leftChild;
		if(maxHeap[largeChild]>maxHeap[position]){
			swap(largeChild,position);
			reheapDown(largeChild,size-1)
		}
	
	}
}

void convertMaxHeaptoMinHeap(int*maxHeap,int size){
	for(int i=1;i<=size;++i)
		reHeapUp(maxHeap,i,size);
}
int main()
{	
	int size=10;
	Node* root=NULL;
	int* arr=new int[size];
	addData(root,size);
	BSTtoHeap(root,arr,size);
	buildHeap(arr,size);
	printHeap(arr,size);
	return 0;
}