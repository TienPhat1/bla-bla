#include <iostream>
using namespace std;

void LeapYear(int year){
	if((year%4==0&&year%100!=0)||year%400==0)
		cout<<year<<" la nam nhuan";
	else
		cout<<year<<" khong phai la nam nhuan";
}
int main(){
	int n;
	cout<<"nhap nam ";cin>>n;
	cout<<endl;
	LeapYear(n);
	return 0;
}