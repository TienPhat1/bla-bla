#include <iostream> 	
#include<cstring>
using namespace std;
//câu a
int CompareString(string str1,string str2){
	int *Arr1=new int[str1.length()];
	int *Arr2=new int[str2.length()];
	for(int i=0;i<str1.length();i++)
		Arr1[i]=str1[i];
	for(int i=0;i<str2.length();i++)
		Arr2[i]=str2[i];
	for(int i=0;i<str1.length();i++)
		if(Arr1[i]!=Arr2[i]){
			return abs(Arr1[i]-Arr2[i]);
		}
	return 0;
}
//câu b
char * FindSpecChar(char cha,char str[]){
	int count=0;
	for(int i=0;i<strlen(str);i++)
		if(cha==str[i])
			return str+i;
	return NULL;

	 return 0;
}
//câu c
char * FindString(char str1[],char str2[]){
	for(int i=0;i<strlen(str2);i++)
		for(int j=0;j<strlen(str1);j++)
			if(str1[j]==str2[i]){
				if(j==strlen(str1)-1)
					return str2+i;
				i++;
				
			}
	return 0;		
}
int main(){
	string str1="abc";
	string str2="cde";
	char a[]="chan";
	char b[]="ch";
	cout<<CompareString(str1,str2)<<endl;
	cout<<FindSpecChar('h',a)<<endl;
	cout<<FindString(b,a);
	return 0;
}