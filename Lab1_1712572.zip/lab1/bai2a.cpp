#include <iostream>
using namespace std;
#define MAXSIZE 100
//hàm nhân 2 matrix
void MultipArray(int Array1[][MAXSIZE],int Array2[][MAXSIZE],int rows1,int cols1,int cols2){
	int Array3[MAXSIZE][MAXSIZE];
	//Tạo mảng 0 Array3 
	for(int i=0;i<rows1;i++)
		for(int j=0;j<cols2;j++)
			Array3[i][j]=0;
	//Thực hiện tính phép nhân 2 mảng
	for(int k=0;k<cols2;k++)
		for(int i=0;i<rows1;i++)
			for(int j=0;j<cols1;j++)
				Array3[i][k]=Array3[i][k]+Array1[i][j]*Array2[j][k];
	//In ra giá trị 
	cout<<"\n";
	for(int i=0;i<rows1;i++){
		for(int j=0;j<cols2;j++)
			cout<<"|"Array3[i][j]<<"|";
		cout<<endl;
	}
}


int main(){

	int Arr1[MAXSIZE][MAXSIZE],Arr2[MAXSIZE][MAXSIZE];
	int rows1,cols1,cols2;
	cout<<"Nhap so luong hang matrix 1"; cin>>row1;cout<<endl;
	cout<<"Nhap so luong cot matrix 1 = hang cot 2"; cin>>cols1;cout<<endl;
	cout<<"Nhap so luong cot matrix 2"; cin>>cols2;cout<<endl;
	for(int i=0;i<rows1;i++)
		for(int j=0;j<cols1;j++)
			cin>>Arr1[i][j];
	cout<<"\n";
	for(int i=0;i<cols1;i++)
		for(int j=0;j<cols2;j++)
			cin>>Arr2[i][j];
	MultipArray(Arr1,Arr2,rows1,cols1,cols2);
	return 0;
}