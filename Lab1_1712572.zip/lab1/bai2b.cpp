#include<iostream>
using namespace std;
//Hàm nhân 2 matrix
void MultipMatrix(int **arr1,int **arr2,int row1,int cols1,int cols2){
	int **arr3;
	arr3=new int*[row1];
	for(int i=0;i<row1;i++)
		arr3[i]=new int[cols2];
	for(int i=0;i<row1;i++)
		for(int j=0;j<cols2;j++){
			arr3[i][j]=0;
		}
	for(int i=0;i<row1;i++){
		for(int j=0;j<cols2;j++)
			cout<<arr3[i][j];
		cout<<endl;
		}	
	for(int k=0;k<cols2;k++){
		for(int j=0;j<row1;j++){
			for(int i=0;i<cols1;i++){
				arr3[j][k]=arr3[j][k]+arr1[j][i]*arr2[i][k];
			}
		}

	}
	for(int i=0;i<row1;i++){
		for(int j=0;j<cols2;j++)
			cout<<"|"<<arr3[i][j]<<"|";
		cout<<endl;
	}
		return;
}
//hàm nhập 2 matrix
void Nhap(int **Arr1,int **Arr2,int row1,int cols1,int cols2){
	for(int i=0;i<row1;i++)
		Arr1[i]=new int[cols1];
	for(int i=0;i<cols1;i++)
		Arr2[i]=new int[cols2];
	for(int i=0;i<row1;i++)
		for(int j=0;j<cols1;j++)
			cin>>Arr1[i][j];
	for(int i=0;i<row1;i++){
		for(int j=0;j<cols1;j++)
			cout<<Arr1[i][j];
		cout<<endl;
	}
	for(int i=0;i<cols1;i++)
		for(int j=0;j<cols2;j++){
			cin>>Arr2[i][j];
		}
	for(int i=0;i<cols1;i++){
		for(int j=0;j<cols2;j++)
			cout<<Arr2[i][j];
		cout<<endl;
	}
}
int main(){
	int row1,cols1,cols2;
	cout<<"Nhap so luong hang matrix 1"; cin>>row1;cout<<endl;
	cout<<"Nhap so luong cot matrix 1 = hang cot 2"; cin>>cols1;cout<<endl;
	cout<<"Nhap so luong cot matrix 2"; cin>>cols2;cout<<endl;
	int **Arr1, **Arr2;
	Arr1=new int*[row1];
	Arr2=new int*[cols1];
	Nhap(Arr1,Arr2,row1,cols1,cols2);
	MultipMatrix(Arr1,Arr2,row1,cols1,cols2);
	return 0;
}