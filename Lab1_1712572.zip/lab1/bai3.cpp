#include <iostream>
using namespace std;
//câu a
long PowerIntRep(int heso,int somu){
	long result=1;
	for(int i=0;i<somu;i++)
		result=result*heso;
	return result;

}
//câu b
long PowerIntRecur(int heso,int somu){
	if(somu==0) return 1;
	else
	return heso*PowerIntRecur(heso,somu-1);
}
int main(){
	cout<<PowerIntRep(2,3);
	cout<<PowerIntRecur(2,3);
	return 0;
}